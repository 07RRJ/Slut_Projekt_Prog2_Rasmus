def Start(data):
    pass