def FindGame(data):
    pass