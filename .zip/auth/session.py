import json
from pathlib import Path
from cryptography.fernet import Fernet
from platformdirs import user_data_dir

APP_NAME = "CardsOfRebelion"
APP_AUTHOR = "07RRJ_Studios"

def _save_path() -> Path:
    folder = Path(user_data_dir(APP_NAME, APP_AUTHOR))
    folder.mkdir(parents=True, exist_ok=True)
    return folder

def _key_file() -> Path:
    return _save_path() / "key.bin"

def _session_file() -> Path:
    return _save_path() / "session.dat"

def _get_or_create_key() -> bytes:
    kf = _key_file()
    if kf.exists():
        return kf.read_bytes()
    key = Fernet.generate_key()
    kf.write_bytes(key)
    return key

def save_session(user_id: str, username: str) -> None:
    f = Fernet(_get_or_create_key())
    data = json.dumps({"user_id": user_id, "username": username}).encode()
    _session_file().write_bytes(f.encrypt(data))

def load_session() -> dict | None:
    sf = _session_file()
    if not sf.exists():
        return None
    try:
        f = Fernet(_get_or_create_key())
        data = f.decrypt(sf.read_bytes())
        return json.loads(data)
    except Exception:
        sf.unlink(missing_ok=True)
        return None

def clear_session() -> None:
    _session_file().unlink(missing_ok=True)