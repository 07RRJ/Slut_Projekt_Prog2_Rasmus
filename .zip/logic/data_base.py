import os
from supabase import create_client, Client
from dotenv import load_dotenv
from logic.functions import GetGameFolder

class Database:
    def __init__(self):
        load_dotenv(GetGameFolder() + "/.env")
        self.client: Client = create_client(
            os.getenv("DATABASE_URL"),
            os.getenv("DATABASE_PASSWORD")
        )

    def register(self, username: str, password_hash: str) -> dict | None:
        res = self.client.table("users").insert({
            "username": username,
            "password_hash": password_hash
        }).execute()
        return res.data[0] if res.data else None

    def login(self, username: str) -> dict | None:
        res = self.client.table("users") \
            .select("*").eq("username", username).single().execute()
        return res.data

    def create_player(self, user_id: str) -> dict:
        res = self.client.table("player").insert({
            "user_id": user_id,
            "gold": 10, "turn": 1, "health": 10, "status": "shopping"
        }).execute()
        return res.data[0]

    def get_player(self, user_id: str) -> dict | None:
        res = self.client.table("player") \
            .select("*").eq("user_id", user_id).single().execute()
        return res.data

    def update_player(self, user_id: str, fields: dict) -> None:
        self.client.table("player").update(fields).eq("user_id", user_id).execute()

    def delete_player(self, user_id: str) -> None:
        self.client.table("player").delete().eq("user_id", user_id).execute()

    def get_pet_catalogue(self) -> list:
        res = self.client.table("pets").select("*").execute()
        return res.data

    def buy_pet(self, user_id: str, pet_id: str, slot: int) -> dict:
        blueprint = self.client.table("pets") \
            .select("*").eq("id", pet_id).single().execute().data
        res = self.client.table("player_pets").insert({
            "user_id": user_id,
            "pet_id": pet_id,
            "slot": slot,
            "attack": blueprint["base_attack"],
            "health": blueprint["base_health"],
            "level": 1,
        }).execute()
        return res.data[0]

    def get_team(self, user_id: str) -> list:
        res = self.client.table("player_pets") \
            .select("*, pets(name, ability)") \
            .eq("user_id", user_id).order("slot").execute()
        return res.data

    def upgrade_pet(self, player_pet_id: str, attack: int, level: int) -> None:
        self.client.table("player_pets") \
            .update({"attack": attack, "level": level}) \
            .eq("id", player_pet_id).execute()

    def sell_pet(self, player_pet_id: str) -> None:
        self.client.table("player_pets").delete().eq("id", player_pet_id).execute()

    def find_or_create_match(self, user_id: str, turn: int) -> dict:
        return self.client.rpc("find_or_create_match", {
            "p_user_id": user_id,
            "p_turn": turn
        }).execute().data