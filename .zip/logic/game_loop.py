def Start(db):
    pass