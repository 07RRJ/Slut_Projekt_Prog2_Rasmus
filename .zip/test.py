# project/
# ├── index.py               # entry point only
# ├── .env                   # supabase keys (never shipped to users)
# ├── auth/
# ├── characters/
# │   ├── __init__.py
# │   ├── base.py            # Base + Unit classes (your existing player.py)
# │   └── pet.py             # Pet instance logic
# ├── logic/
# │   ├── __init__.py
# │   ├── functions.py       # path helpers (keep as-is)
# │   ├── database.py        # all supabase calls
# │   ├── matchmaking.py     # find/create game logic
# │   └── game_loop.py       # battle logic
# └── ui/
#     ├── __init__.py
#     ├── loading.py
#     ├── menu.py
#     └── game.py